# FOOTBALL AI Android

갤럭시에서 설치할 수 있는 Android 앱 프로젝트입니다. 앱에서 영상을 선택하고 서버 분석 결과를 다운로드할 수 있습니다.

GitHub Actions의 `Build Android APK` 작업이 끝나면 `football-ai-apk` 결과물 안에서 APK를 받을 수 있습니다.
